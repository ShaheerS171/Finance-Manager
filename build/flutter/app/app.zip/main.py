"""
Transport Fee Manager - Main Application
A comprehensive fee management system for transport and events
"""

import flet as ft
from database import DatabaseManager
from ui.home_screen import HomeScreen
from ui.transport_screen import TransportScreen
from ui.events_screen import EventsScreen
from ui.principal_screen import PrincipalScreen
from ui.teacher_debt_screen import TeacherDebtScreen


class TransportFeeManager:
    """Main application class"""
    
    def __init__(self, page: ft.Page):
        print("TransportFeeManager.__init__ started")
        self.page = page
        self.page.title = "Transport Fee Manager"
        self.page.theme_mode = ft.ThemeMode.LIGHT
        self.page.padding = 0
        self.page.on_resize = self.handle_resize
        
        # Determine mobile-safe database path
        import os
        db_path = "data/fee_manager.db"
        if os.environ.get("FLET_PLATFORM") in ["android", "ios"]:
            os.makedirs("data", exist_ok=True)
            db_path = os.path.join(os.getcwd(), "data", "fee_manager.db")
            
        # Initialize database
        self.db = DatabaseManager(db_path=db_path)
        
        # Current screen index
        self.selected_index = 0
        self.current_screen = None
        
        # UI Components
        self.build_components()
        self.build_ui()
        
        # Request permissions on mobile
        if os.environ.get("FLET_PLATFORM") in ["android", "ios"]:
            self.request_mobile_permissions()

    def request_mobile_permissions(self):
        """Explicitly request storage permissions for Android"""
        # This is a bit tricky with pure Flet, but we can try to trigger it 
        # by accessing a file or using a picker.
        # However, listing them in flet.yaml is the primary way.
        pass
    
    def build_components(self):
        """Build independent UI components"""
        # Theme Toggle
        self.theme_toggle = ft.IconButton(
            icon=ft.Icons.DARK_MODE_OUTLINED,
            on_click=self.toggle_theme,
            tooltip="Toggle Light/Dark Mode"
        )

        # Navigation destinations
        self.nav_destinations = [
            ft.NavigationRailDestination(
                icon=ft.Icons.DASHBOARD_OUTLINED,
                selected_icon=ft.Icons.DASHBOARD,
                label="Dashboard",
            ),
            ft.NavigationRailDestination(
                icon=ft.Icons.DIRECTIONS_BUS_OUTLINED,
                selected_icon=ft.Icons.DIRECTIONS_BUS,
                label="Transport",
            ),
            ft.NavigationRailDestination(
                icon=ft.Icons.EVENT_OUTLINED,
                selected_icon=ft.Icons.EVENT,
                label="Events",
            ),
            ft.NavigationRailDestination(
                icon=ft.Icons.ATTACH_MONEY_OUTLINED,
                selected_icon=ft.Icons.ATTACH_MONEY,
                label="Principal",
            ),
            ft.NavigationRailDestination(
                icon=ft.Icons.PEOPLE_OUTLINED,
                selected_icon=ft.Icons.PEOPLE,
                label="Teachers",
            ),
        ]

        # Navigation Rail (Desktop)
        self.nav_rail = ft.NavigationRail(
            selected_index=self.selected_index,
            label_type=ft.NavigationRailLabelType.ALL,
            min_width=100,
            min_extended_width=200,
            group_alignment=-0.9,
            destinations=self.nav_destinations,
            on_change=self.navigate,
            trailing=ft.Container(self.theme_toggle, padding=ft.padding.only(bottom=20))
        )

        # Navigation Bar (Mobile)
        self.nav_bar = ft.NavigationBar(
            selected_index=self.selected_index,
            destinations=[
                ft.NavigationBarDestination(icon=ft.Icons.DASHBOARD_OUTLINED, selected_icon=ft.Icons.DASHBOARD, label="Dash"),
                ft.NavigationBarDestination(icon=ft.Icons.DIRECTIONS_BUS_OUTLINED, selected_icon=ft.Icons.DIRECTIONS_BUS, label="Trans"),
                ft.NavigationBarDestination(icon=ft.Icons.EVENT_OUTLINED, selected_icon=ft.Icons.EVENT, label="Events"),
                ft.NavigationBarDestination(icon=ft.Icons.ATTACH_MONEY_OUTLINED, selected_icon=ft.Icons.ATTACH_MONEY, label="Princ"),
                ft.NavigationBarDestination(icon=ft.Icons.PEOPLE_OUTLINED, selected_icon=ft.Icons.PEOPLE, label="Teach"),
            ],
            on_change=self.navigate,
        )
        
        # Content area
        self.content_area = ft.Container(
            expand=True,
            bgcolor="surfaceVariant",
        )

    def build_ui(self):
        """Build the main user interface based on screen width"""
        self.page.controls.clear()
        
        if self.page.width < 600:
            # Mobile layout: Content on top, NavigationBar at bottom
            self.page.navigation_bar = self.nav_bar
            self.page.add(self.content_area)
            # Add a small theme toggle in mobile view since nav_rail is hidden
            if not any(isinstance(c, ft.AppBar) for c in self.page.controls if isinstance(c, ft.AppBar)):
                 self.page.appbar = ft.AppBar(
                     title=ft.Text("Fee Manager", size=20),
                     actions=[self.theme_toggle],
                     bgcolor=ft.Colors.SURFACE_VARIANT,
                 )
        else:
            # Desktop layout: NavigationRail on left, Content on right
            self.page.navigation_bar = None
            self.page.appbar = None
            main_layout = ft.Row(
                [
                    self.nav_rail,
                    ft.VerticalDivider(width=1),
                    self.content_area,
                ],
                expand=True,
                spacing=0,
            )
            self.page.add(main_layout)
        
        # Load current screen
        self.load_screen(self.selected_index)
        self.page.update()
    
    def handle_resize(self, e):
        """Handle page resize to switch layout"""
        self.build_ui()

    def navigate(self, e):
        """Handle navigation"""
        self.selected_index = int(e.data) if hasattr(e, "data") else e.control.selected_index
        self.nav_rail.selected_index = self.selected_index
        self.nav_bar.selected_index = self.selected_index
        self.load_screen(self.selected_index)
    
    def load_screen(self, index):
        """Load the selected screen"""
        # Clear current content
        self.content_area.content = None
        
        # Load new screen
        if index == 0:
            self.current_screen = HomeScreen(self.db, self.page)
        elif index == 1:
            self.current_screen = TransportScreen(self.db, self.page)
        elif index == 2:
            self.current_screen = EventsScreen(self.db, self.page)
        elif index == 3:
            self.current_screen = PrincipalScreen(self.db, self.page)
        elif index == 4:
            self.current_screen = TeacherDebtScreen(self.db, self.page)
        
        # Update content area
        self.content_area.content = self.current_screen
        self.page.update()
    
    def refresh_current_screen(self):
        """Refresh the current screen"""
        if hasattr(self.current_screen, 'refresh'):
            self.current_screen.refresh()

    def toggle_theme(self, e):
        """Toggle between light and dark theme"""
        if self.page.theme_mode == ft.ThemeMode.LIGHT:
            self.page.theme_mode = ft.ThemeMode.DARK
            self.theme_toggle.icon = ft.Icons.LIGHT_MODE
        else:
            self.page.theme_mode = ft.ThemeMode.LIGHT
            self.theme_toggle.icon = ft.Icons.DARK_MODE_OUTLINED
        
        self.page.update()


def main(page: ft.Page):
    """Main entry point"""
    TransportFeeManager(page)


if __name__ == "__main__":
    ft.app(target=main)


import csv
import openpyxl
from database.models import Student

def import_students_from_file(file_path, db_manager):
    """
    Imports students from CSV or Excel.
    Expected columns (case-insensitive): Name, Father Name, Class, Section, Bus, Stop, Phone, Monthly Fee
    """
    students_to_add = []
    errors = []
    
    # Load all buses for mapping names to IDs
    buses = db_manager.get_all_buses()
    bus_map = {b.name.lower(): b.id for b in buses}
    
    import os
    if not os.path.exists(file_path):
        return 0, [f"File not found: {file_path}"]
    
    try:
        # Check if we can read the file
        if not os.access(file_path, os.R_OK):
            return 0, [f"Permission denied: Cannot read {file_path}. Try moving the file to app storage."]
            
        if file_path.endswith('.csv'):
            with open(file_path, mode='r', encoding='utf-8-sig') as f:
                reader = csv.DictReader(f)
                headers = reader.fieldnames
                header_map = map_headers(headers)
                for i, row in enumerate(reader, 2):
                    student, error = parse_row(row, header_map, bus_map, db_manager)
                    if student:
                        students_to_add.append(student)
                    if error:
                        errors.append(f"Row {i}: {error}")
        elif file_path.endswith('.xlsx'):
            wb = openpyxl.load_workbook(file_path, data_only=True)
            sheet = wb.active
            headers = [str(cell.value) if cell.value else "" for cell in sheet[1]]
            header_map = map_headers(headers)
            for i, row in enumerate(sheet.iter_rows(min_row=2, values_only=True), 2):
                data = dict(zip(headers, row))
                student, error = parse_row(data, header_map, bus_map, db_manager)
                if student:
                    students_to_add.append(student)
                if error:
                    errors.append(f"Row {i}: {error}")
    except Exception as e:
        return 0, [f"File error: {str(e)}"]
            
    count = 0
    for s in students_to_add:
        try:
            db_manager.add_student(s)
            count += 1
        except Exception as e:
            errors.append(f"DB error for {s.name}: {str(e)}")
            
    return count, errors

def map_headers(headers):
    """Maps spreadsheet headers to expected internal field names using fuzzy matching"""
    mapping = {
        'name': ['name', 'student name', 'student_name', 'full name'],
        'father_name': ['father name', 'father_name', 'father', 'guardian'],
        'class_name': ['class', 'class_name', 'grade', 'standard'],
        'section': ['section', 'sec'],
        'bus': ['bus', 'route', 'bus name', 'bus_name'],
        'stop': ['stop', 'bus stop', 'bus_stop', 'location'],
        'phone': ['phone', 'mobile', 'contact', 'phone number', 'mobile number'],
        'monthly_fee': ['monthly fee', 'monthly_fee', 'fee', 'charge', 'amount']
    }
    
    header_map = {}
    if not headers: return header_map
    
    for internal_key, variations in mapping.items():
        for h in headers:
            if not h: continue
            clean_h = str(h).strip().lower().replace('_', ' ')
            if clean_h in variations or any(v in clean_h for v in variations):
                header_map[internal_key] = h
                break
    return header_map

def parse_row(row, header_map, bus_map, db_manager):
    """Helper to parse a single row from file row dict"""
    try:
        def get_val(key):
            actual_header = header_map.get(key)
            if actual_header is None: return None
            val = row.get(actual_header)
            return str(val).strip() if val is not None else ""

        name = get_val('name')
        if not name: return None, "Missing name"
        
        bus_name = get_val('bus')
        bus_id = None
        if bus_name:
            bus_id = bus_map.get(bus_name.lower())
            if not bus_id:
                from database.models import Bus
                new_bus = Bus(name=bus_name, default_target=0)
                bus_id = db_manager.add_bus(new_bus)
                bus_map[bus_name.lower()] = bus_id
        
        fee_str = get_val('monthly_fee') or "0"
        try:
            monthly_fee = float(fee_str.replace(',', ''))
        except:
            monthly_fee = 0
        
        student = Student(
            name=name,
            father_name=get_val('father_name') or "",
            class_name=get_val('class_name') or "",
            section=get_val('section') or "",
            bus_id=bus_id,
            bus_stop=get_val('stop') or "",
            phone=get_val('phone') or "",
            monthly_fee=monthly_fee,
            target_amount=monthly_fee,
            paid_amount=0
        )
        return student, None
    except Exception as e:
        return None, str(e)
